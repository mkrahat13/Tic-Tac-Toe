import type { Player } from './types';

export type HapticPattern = 'ui' | 'move' | 'aiMove' | 'invalid' | 'win' | 'draw';

const HAPTIC_PATTERNS: Record<HapticPattern, number | number[]> = {
  ui: 8,
  move: 14,
  aiMove: 9,
  invalid: [12, 28, 12],
  win: [16, 40, 22, 40, 38],
  draw: [14, 36, 14],
};

class FeedbackEngine {
  private ctx: AudioContext | null = null;
  private soundEnabled = true;
  private hapticsEnabled = true;

  public configure(sound: boolean, haptics: boolean) {
    this.soundEnabled = sound;
    this.hapticsEnabled = haptics;
  }

  public isVibrationSupported(): boolean {
    return typeof navigator !== 'undefined' && typeof navigator.vibrate === 'function';
  }

  private getAudioContext(): AudioContext | null {
    if (!this.soundEnabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return null;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  public vibrate(pattern: HapticPattern) {
    if (!this.hapticsEnabled) return;
    if (this.isVibrationSupported()) {
      try {
        navigator.vibrate(HAPTIC_PATTERNS[pattern]);
      } catch {
        // Ignore browser vibration restrictions
      }
    }
  }

  private playTone(
    freq: number,
    durationSec: number,
    type: OscillatorType,
    peakGain: number,
    delaySec = 0,
    endFreq?: number,
  ) {
    const ctx = this.getAudioContext();
    if (!ctx) return;

    const now = ctx.currentTime + delaySec;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);
    if (endFreq !== undefined) {
      osc.frequency.exponentialRampToValueAtTime(endFreq, now + durationSec);
    }

    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(peakGain, now + 0.008);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + durationSec);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + durationSec + 0.02);
  }

  public tapUI() {
    this.vibrate('ui');
    this.playTone(540, 0.032, 'sine', 0.038, 0, 420);
  }

  public placeMark(player: Player, isAI = false) {
    this.vibrate(isAI ? 'aiMove' : 'move');
    if (player === 'X') {
      // Crisp percussive tactile woodblock-like ping for X
      this.playTone(523.25, 0.09, 'triangle', 0.09, 0, 620);
      this.playTone(1046.5, 0.055, 'sine', 0.032, 0.012);
    } else {
      // Warm rounded resonant chime for O
      this.playTone(392.0, 0.11, 'sine', 0.095, 0, 440);
      this.playTone(587.33, 0.07, 'triangle', 0.035, 0.018);
    }
  }

  public invalidTap() {
    this.vibrate('invalid');
    this.playTone(175, 0.07, 'triangle', 0.06, 0, 140);
  }

  public restartRound() {
    this.vibrate('ui');
    this.playTone(440, 0.065, 'sine', 0.045, 0, 587.33);
  }

  public celebrateWin() {
    this.vibrate('win');
    // Ascending Material chime (C5 -> E5 -> G5 -> C6)
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((freq, idx) => {
      this.playTone(freq, 0.24, 'triangle', 0.075, idx * 0.075);
      this.playTone(freq * 0.5, 0.2, 'sine', 0.035, idx * 0.075);
    });
  }

  public announceDraw() {
    this.vibrate('draw');
    this.playTone(440, 0.14, 'sine', 0.06, 0);
    this.playTone(392, 0.22, 'sine', 0.06, 0.11);
  }
}

export const feedback = new FeedbackEngine();
