import type { ThemeMode } from './types';

export interface SeedPreset {
  id: string;
  name: string;
  hex: string;
}

export const MATERIAL_YOU_PRESETS: SeedPreset[] = [
  { id: 'cobalt', name: 'Ocean Blue', hex: '#2554C7' },
  { id: 'sage', name: 'Forest Sage', hex: '#2E6F5E' },
  { id: 'orchid', name: 'Orchid Plum', hex: '#7C43A8' },
  { id: 'terracotta', name: 'Sienna Clay', hex: '#B84A39' },
  { id: 'amber', name: 'Golden Ochre', hex: '#9A6300' },
  { id: 'teal', name: 'Lagoon Teal', hex: '#006B76' },
];

const DYNAMIC_TOKEN_KEYS = [
  '--m3-surface',
  '--m3-surface-dim',
  '--m3-surface-container-lowest',
  '--m3-surface-container-low',
  '--m3-surface-container',
  '--m3-surface-container-high',
  '--m3-surface-container-highest',
  '--m3-on-surface',
  '--m3-on-surface-variant',
  '--m3-outline',
  '--m3-outline-variant',
  '--m3-primary',
  '--m3-on-primary',
  '--m3-primary-container',
  '--m3-on-primary-container',
  '--m3-tertiary',
  '--m3-on-tertiary',
  '--m3-tertiary-container',
  '--m3-on-tertiary-container',
  '--m3-secondary',
  '--m3-secondary-container',
  '--m3-on-secondary-container',
] as const;

function hexToHsl(hex: string): { h: number; s: number; l: number } {
  const clean = hex.replace('#', '').trim();
  const full =
    clean.length === 3
      ? clean
          .split('')
          .map((c) => c + c)
          .join('')
      : clean.padEnd(6, '0').slice(0, 6);

  const r = parseInt(full.slice(0, 2), 16) / 255;
  const g = parseInt(full.slice(2, 4), 16) / 255;
  const b = parseInt(full.slice(4, 6), 16) / 255;

  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  const delta = max - min;

  let h = 0;
  if (delta !== 0) {
    if (max === r) {
      h = ((g - b) / delta) % 6;
    } else if (max === g) {
      h = (b - r) / delta + 2;
    } else {
      h = (r - g) / delta + 4;
    }
    h = Math.round(h * 60);
    if (h < 0) h += 360;
  }

  const l = (max + min) / 2;
  const s = delta === 0 ? 0 : delta / (1 - Math.abs(2 * l - 1));

  return { h, s: Math.round(s * 100), l: Math.round(l * 100) };
}

function hsl(h: number, s: number, l: number): string {
  const wrappedHue = ((Math.round(h) % 360) + 360) % 360;
  const clampedS = Math.max(0, Math.min(100, Math.round(s)));
  const clampedL = Math.max(0, Math.min(100, Math.round(l)));
  return `hsl(${wrappedHue} ${clampedS}% ${clampedL}%)`;
}

/**
 * Generates a WCAG-AA-balanced Material You (M3) tonal palette from a seed color.
 * Computes primary, harmonious tertiary (+135° for strong X vs O distinction),
 * neutral-tinted surfaces, and neutral-variant outlines for light or dark mode.
 */
export function buildMaterialYouTokens(
  seedHex: string,
  theme: ThemeMode,
): Record<string, string> {
  const { h, s } = hexToHsl(seedHex);
  const primaryHue = h;
  const primaryChroma = Math.max(46, Math.min(78, s));
  // Split-complementary tertiary hue ensures X and O always stay distinct & accessible
  const tertiaryHue = (h + 138) % 360;
  const tertiaryChroma = Math.max(48, Math.min(74, primaryChroma));
  const neutralS = Math.min(14, Math.max(6, Math.round(s * 0.16)));
  const neutralVarS = Math.min(20, Math.max(9, Math.round(s * 0.24)));

  if (theme === 'dark') {
    return {
      '--m3-surface': hsl(primaryHue, neutralS, 8),
      '--m3-surface-dim': hsl(primaryHue, neutralS, 6),
      '--m3-surface-container-lowest': hsl(primaryHue, neutralS, 10),
      '--m3-surface-container-low': hsl(primaryHue, neutralS, 12),
      '--m3-surface-container': hsl(primaryHue, neutralS, 14),
      '--m3-surface-container-high': hsl(primaryHue, neutralS, 18),
      '--m3-surface-container-highest': hsl(primaryHue, neutralS, 22),

      '--m3-on-surface': hsl(primaryHue, 14, 92),
      '--m3-on-surface-variant': hsl(primaryHue, neutralVarS, 73),
      '--m3-outline': hsl(primaryHue, neutralVarS, 54),
      '--m3-outline-variant': hsl(primaryHue, neutralVarS, 27),

      '--m3-primary': hsl(primaryHue, Math.min(92, primaryChroma + 14), 76),
      '--m3-on-primary': hsl(primaryHue, Math.min(75, primaryChroma), 16),
      '--m3-primary-container': hsl(primaryHue, Math.min(62, primaryChroma), 26),
      '--m3-on-primary-container': hsl(primaryHue, 90, 91),

      '--m3-tertiary': hsl(tertiaryHue, Math.min(88, tertiaryChroma + 12), 76),
      '--m3-on-tertiary': hsl(tertiaryHue, Math.min(75, tertiaryChroma), 16),
      '--m3-tertiary-container': hsl(tertiaryHue, Math.min(60, tertiaryChroma), 26),
      '--m3-on-tertiary-container': hsl(tertiaryHue, 90, 91),

      '--m3-secondary': hsl(primaryHue, Math.max(20, neutralVarS + 10), 75),
      '--m3-secondary-container': hsl(primaryHue, Math.max(18, neutralVarS + 6), 24),
      '--m3-on-secondary-container': hsl(primaryHue, 35, 90),
    };
  }

  return {
    '--m3-surface': hsl(primaryHue, Math.min(28, neutralS + 10), 97),
    '--m3-surface-dim': hsl(primaryHue, Math.min(24, neutralS + 8), 91),
    '--m3-surface-container-lowest': '#ffffff',
    '--m3-surface-container-low': hsl(primaryHue, Math.min(26, neutralS + 10), 95),
    '--m3-surface-container': hsl(primaryHue, Math.min(26, neutralS + 10), 92),
    '--m3-surface-container-high': hsl(primaryHue, Math.min(26, neutralS + 10), 89),
    '--m3-surface-container-highest': hsl(primaryHue, Math.min(24, neutralS + 10), 86),

    '--m3-on-surface': hsl(primaryHue, 22, 11),
    '--m3-on-surface-variant': hsl(primaryHue, neutralVarS, 34),
    '--m3-outline': hsl(primaryHue, neutralVarS, 49),
    '--m3-outline-variant': hsl(primaryHue, neutralVarS, 80),

    '--m3-primary': hsl(primaryHue, primaryChroma, 41),
    '--m3-on-primary': '#ffffff',
    '--m3-primary-container': hsl(primaryHue, Math.min(88, primaryChroma + 12), 89),
    '--m3-on-primary-container': hsl(primaryHue, Math.min(80, primaryChroma + 6), 19),

    '--m3-tertiary': hsl(tertiaryHue, tertiaryChroma, 42),
    '--m3-on-tertiary': '#ffffff',
    '--m3-tertiary-container': hsl(tertiaryHue, Math.min(88, tertiaryChroma + 12), 90),
    '--m3-on-tertiary-container': hsl(tertiaryHue, Math.min(80, tertiaryChroma + 6), 20),

    '--m3-secondary': hsl(primaryHue, Math.max(18, neutralVarS + 6), 38),
    '--m3-secondary-container': hsl(primaryHue, Math.max(22, neutralVarS + 8), 89),
    '--m3-on-secondary-container': hsl(primaryHue, 32, 19),
  };
}

export function applyDynamicColorsToRoot(seedHex: string, theme: ThemeMode) {
  if (typeof document === 'undefined') return;
  const rootStyle = document.documentElement.style;
  const tokens = buildMaterialYouTokens(seedHex, theme);
  for (const [key, value] of Object.entries(tokens)) {
    rootStyle.setProperty(key, value);
  }
}

export function clearDynamicColorsFromRoot() {
  if (typeof document === 'undefined') return;
  const rootStyle = document.documentElement.style;
  for (const key of DYNAMIC_TOKEN_KEYS) {
    rootStyle.removeProperty(key);
  }
}
