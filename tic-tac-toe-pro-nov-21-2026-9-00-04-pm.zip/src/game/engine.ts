import type { AIDifficulty, BoardState, Player, WinInfo, WinLineGeometry } from './types';

interface WinningLineDef {
  cells: [number, number, number];
  geometry: WinLineGeometry;
  label: string;
}

// ViewBox is 300x300 (each cell is 100x100 with centers at 50, 150, 250)
export const WINNING_LINES: WinningLineDef[] = [
  {
    cells: [0, 1, 2],
    geometry: { x1: 28, y1: 50, x2: 272, y2: 50 },
    label: 'Top row',
  },
  {
    cells: [3, 4, 5],
    geometry: { x1: 28, y1: 150, x2: 272, y2: 150 },
    label: 'Middle row',
  },
  {
    cells: [6, 7, 8],
    geometry: { x1: 28, y1: 250, x2: 272, y2: 250 },
    label: 'Bottom row',
  },
  {
    cells: [0, 3, 6],
    geometry: { x1: 50, y1: 28, x2: 50, y2: 272 },
    label: 'Left column',
  },
  {
    cells: [1, 4, 7],
    geometry: { x1: 150, y1: 28, x2: 150, y2: 272 },
    label: 'Center column',
  },
  {
    cells: [2, 5, 8],
    geometry: { x1: 250, y1: 28, x2: 250, y2: 272 },
    label: 'Right column',
  },
  {
    cells: [0, 4, 8],
    geometry: { x1: 34, y1: 34, x2: 266, y2: 266 },
    label: 'Main diagonal',
  },
  {
    cells: [2, 4, 6],
    geometry: { x1: 266, y1: 34, x2: 34, y2: 266 },
    label: 'Anti-diagonal',
  },
];

export function createEmptyBoard(): BoardState {
  return Array<null>(9).fill(null);
}

export function getOpponent(player: Player): Player {
  return player === 'X' ? 'O' : 'X';
}

export function checkWinner(board: BoardState): WinInfo | null {
  for (const def of WINNING_LINES) {
    const [a, b, c] = def.cells;
    const cell = board[a];
    if (cell && cell === board[b] && cell === board[c]) {
      return {
        winner: cell,
        line: def.cells,
        geometry: def.geometry,
        label: def.label,
      };
    }
  }
  return null;
}

export function isBoardFull(board: BoardState): boolean {
  return board.every((cell) => cell !== null);
}

export function getAvailableMoves(board: BoardState): number[] {
  const moves: number[] = [];
  for (let i = 0; i < board.length; i++) {
    if (board[i] === null) moves.push(i);
  }
  return moves;
}

function findImmediateWinningMove(board: BoardState, player: Player): number | null {
  const available = getAvailableMoves(board);
  for (const idx of available) {
    const next = [...board];
    next[idx] = player;
    if (checkWinner(next)?.winner === player) {
      return idx;
    }
  }
  return null;
}

function minimax(
  board: BoardState,
  depth: number,
  isMaximizing: boolean,
  aiPlayer: Player,
  humanPlayer: Player,
  alpha: number,
  beta: number,
): number {
  const win = checkWinner(board);
  if (win) {
    return win.winner === aiPlayer ? 10 - depth : depth - 10;
  }
  if (isBoardFull(board)) {
    return 0;
  }

  const available = getAvailableMoves(board);

  if (isMaximizing) {
    let best = -Infinity;
    for (const move of available) {
      board[move] = aiPlayer;
      const score = minimax(board, depth + 1, false, aiPlayer, humanPlayer, alpha, beta);
      board[move] = null;
      if (score > best) best = score;
      if (best > alpha) alpha = best;
      if (beta <= alpha) break;
    }
    return best;
  } else {
    let best = Infinity;
    for (const move of available) {
      board[move] = humanPlayer;
      const score = minimax(board, depth + 1, true, aiPlayer, humanPlayer, alpha, beta);
      board[move] = null;
      if (score < best) best = score;
      if (best < beta) beta = best;
      if (beta <= alpha) break;
    }
    return best;
  }
}

function getOptimalMinimaxMove(board: BoardState, aiPlayer: Player): number {
  const available = getAvailableMoves(board);
  if (available.length === 0) return -1;

  // Fast opening heuristic when AI moves first on an empty board
  if (available.length === 9) {
    const preferredOpenings = [0, 2, 4, 6, 8];
    return preferredOpenings[Math.floor(Math.random() * preferredOpenings.length)];
  }

  const humanPlayer = getOpponent(aiPlayer);
  const working = [...board];
  let bestScore = -Infinity;
  let bestMoves: number[] = [];

  for (const move of available) {
    working[move] = aiPlayer;
    const score = minimax(working, 0, false, aiPlayer, humanPlayer, -Infinity, Infinity);
    working[move] = null;

    if (score > bestScore) {
      bestScore = score;
      bestMoves = [move];
    } else if (score === bestScore) {
      bestMoves.push(move);
    }
  }

  return bestMoves[Math.floor(Math.random() * bestMoves.length)];
}

export function getBestAIMove(
  board: BoardState,
  aiPlayer: Player,
  difficulty: AIDifficulty,
): number {
  const available = getAvailableMoves(board);
  if (available.length === 0) return -1;

  const humanPlayer = getOpponent(aiPlayer);

  if (difficulty === 'unbeatable') {
    return getOptimalMinimaxMove(board, aiPlayer);
  }

  if (difficulty === 'smart') {
    // Always seize immediate win or block immediate threat
    const winMove = findImmediateWinningMove(board, aiPlayer);
    if (winMove !== null) return winMove;

    const blockMove = findImmediateWinningMove(board, humanPlayer);
    if (blockMove !== null) return blockMove;

    // 68% optimal minimax, 32% strategic center/corner/random for winnable variety
    if (Math.random() < 0.68) {
      return getOptimalMinimaxMove(board, aiPlayer);
    }

    const strategic = [4, 0, 2, 6, 8].filter((i) => board[i] === null);
    if (strategic.length > 0 && Math.random() < 0.6) {
      return strategic[Math.floor(Math.random() * strategic.length)];
    }
    return available[Math.floor(Math.random() * available.length)];
  }

  // 'casual' difficulty: fun and forgiving for quick relaxed play
  const winMove = findImmediateWinningMove(board, aiPlayer);
  if (winMove !== null && Math.random() < 0.65) {
    return winMove;
  }

  const blockMove = findImmediateWinningMove(board, humanPlayer);
  if (blockMove !== null && Math.random() < 0.4) {
    return blockMove;
  }

  return available[Math.floor(Math.random() * available.length)];
}
