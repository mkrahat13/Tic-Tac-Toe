import { useCallback, useEffect, useRef, useState } from 'react';
import {
  ArrowLeft,
  Bot,
  Moon,
  RotateCcw,
  Settings,
  Sun,
  Trash2,
  Trophy,
  Users,
  Vibrate,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { Board } from './components/Board';
import { MarkGlyph } from './components/MarkGlyph';
import { ResultModal } from './components/ResultModal';
import { SettingsModal } from './components/SettingsModal';
import { TitleScreen } from './components/TitleScreen';
import {
  applyDynamicColorsToRoot,
  clearDynamicColorsFromRoot,
  MATERIAL_YOU_PRESETS,
} from './game/dynamicColors';
import {
  checkWinner,
  createEmptyBoard,
  getBestAIMove,
  getOpponent,
  isBoardFull,
} from './game/engine';
import { feedback } from './game/feedback';
import type {
  AIDifficulty,
  BoardState,
  GameMode,
  GameScreen,
  Player,
  RoundResult,
  ScoreBoard,
  ThemeMode,
  UIStyle,
} from './game/types';

const STORAGE_KEYS = {
  theme: 'ttt-theme',
  uiStyle: 'ttt-ui-style',
  dynamicColors: 'ttt-dynamic-colors',
  seedColor: 'ttt-seed-color',
  sound: 'ttt-sound',
  haptics: 'ttt-haptics',
  scores: 'ttt-scores-v1',
};

const EMPTY_SCORES: Record<GameMode, ScoreBoard> = {
  ai: { X: 0, O: 0, draws: 0 },
  local: { X: 0, O: 0, draws: 0 },
};

function readInitialTheme(): ThemeMode {
  if (typeof window === 'undefined') return 'light';
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.theme);
    if (saved === 'dark' || saved === 'light') return saved;
  } catch {
    // ignore storage errors
  }
  return document.documentElement.classList.contains('dark') ? 'dark' : 'light';
}

function readInitialUIStyle(): UIStyle {
  if (typeof window === 'undefined') return 'material3';
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.uiStyle);
    if (saved === 'liquid-glass' || saved === 'material3') return saved;
  } catch {
    // ignore
  }
  return 'material3';
}

function readInitialSeedColor(): string {
  if (typeof window === 'undefined') return MATERIAL_YOU_PRESETS[0].hex;
  try {
    const saved = localStorage.getItem(STORAGE_KEYS.seedColor);
    if (saved && /^#[0-9a-fA-F]{6}$/.test(saved)) return saved;
  } catch {
    // ignore
  }
  return MATERIAL_YOU_PRESETS[0].hex;
}

function readInitialBoolean(key: string, fallback: boolean): boolean {
  if (typeof window === 'undefined') return fallback;
  try {
    const saved = localStorage.getItem(key);
    if (saved === 'true') return true;
    if (saved === 'false') return false;
  } catch {
    // ignore
  }
  return fallback;
}

function readInitialScores(): Record<GameMode, ScoreBoard> {
  if (typeof window === 'undefined') return EMPTY_SCORES;
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.scores);
    if (!raw) return EMPTY_SCORES;
    const parsed = JSON.parse(raw) as Partial<Record<GameMode, ScoreBoard>>;
    return {
      ai: {
        X: Number(parsed.ai?.X) || 0,
        O: Number(parsed.ai?.O) || 0,
        draws: Number(parsed.ai?.draws) || 0,
      },
      local: {
        X: Number(parsed.local?.X) || 0,
        O: Number(parsed.local?.O) || 0,
        draws: Number(parsed.local?.draws) || 0,
      },
    };
  } catch {
    return EMPTY_SCORES;
  }
}

const DIFFICULTY_LABELS: Record<AIDifficulty, string> = {
  casual: 'Casual',
  smart: 'Smart',
  unbeatable: 'Unbeatable',
};

export default function App() {
  const [screen, setScreen] = useState<GameScreen>('TITLE_MENU');
  const [mode, setMode] = useState<GameMode>('ai');
  const [difficulty, setDifficulty] = useState<AIDifficulty>('smart');
  const [humanMark, setHumanMark] = useState<Player>('X');

  const [theme, setTheme] = useState<ThemeMode>(readInitialTheme);
  const [uiStyle, setUIStyle] = useState<UIStyle>(readInitialUIStyle);
  const [dynamicColorsEnabled, setDynamicColorsEnabled] = useState<boolean>(() =>
    readInitialBoolean(STORAGE_KEYS.dynamicColors, false),
  );
  const [seedColor, setSeedColor] = useState<string>(readInitialSeedColor);
  const [showSettings, setShowSettings] = useState<boolean>(false);

  const [soundEnabled, setSoundEnabled] = useState<boolean>(() =>
    readInitialBoolean(STORAGE_KEYS.sound, true),
  );
  const [hapticsEnabled, setHapticsEnabled] = useState<boolean>(() =>
    readInitialBoolean(STORAGE_KEYS.haptics, true),
  );

  const [board, setBoard] = useState<BoardState>(createEmptyBoard);
  const [currentTurn, setCurrentTurn] = useState<Player>('X');
  const [startingPlayer, setStartingPlayer] = useState<Player>('X');
  const [roundNumber, setRoundNumber] = useState<number>(1);
  const [lastMoveIndex, setLastMoveIndex] = useState<number | null>(null);
  const [isAIThinking, setIsAIThinking] = useState<boolean>(false);

  const [scoresByMode, setScoresByMode] =
    useState<Record<GameMode, ScoreBoard>>(readInitialScores);
  const [roundResult, setRoundResult] = useState<RoundResult | null>(null);
  const [showResultModal, setShowResultModal] = useState<boolean>(false);

  const aiTimerRef = useRef<number | null>(null);
  const modalTimerRef = useRef<number | null>(null);

  const clearPendingTimers = useCallback(() => {
    if (aiTimerRef.current !== null) {
      window.clearTimeout(aiTimerRef.current);
      aiTimerRef.current = null;
    }
    if (modalTimerRef.current !== null) {
      window.clearTimeout(modalTimerRef.current);
      modalTimerRef.current = null;
    }
  }, []);

  // Sync dark/light theme to document root & localStorage
  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
    } else {
      root.classList.remove('dark');
    }
    try {
      localStorage.setItem(STORAGE_KEYS.theme, theme);
    } catch {
      // ignore
    }
  }, [theme]);

  // Sync UI Style (Material 3 vs Liquid Glass) & Material You Dynamic Colors
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute('data-ui-style', uiStyle);

    // Dynamic Colors (Material You) strictly apply ONLY when Material 3 is enabled
    if (uiStyle === 'material3' && dynamicColorsEnabled) {
      applyDynamicColorsToRoot(seedColor, theme);
    } else {
      clearDynamicColorsFromRoot();
    }

    try {
      localStorage.setItem(STORAGE_KEYS.uiStyle, uiStyle);
      localStorage.setItem(STORAGE_KEYS.dynamicColors, String(dynamicColorsEnabled));
      localStorage.setItem(STORAGE_KEYS.seedColor, seedColor);
    } catch {
      // ignore
    }
  }, [uiStyle, dynamicColorsEnabled, seedColor, theme]);

  // Sync audio & haptics configuration
  useEffect(() => {
    feedback.configure(soundEnabled, hapticsEnabled);
    try {
      localStorage.setItem(STORAGE_KEYS.sound, String(soundEnabled));
      localStorage.setItem(STORAGE_KEYS.haptics, String(hapticsEnabled));
    } catch {
      // ignore
    }
  }, [soundEnabled, hapticsEnabled]);

  // Persist scores
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.scores, JSON.stringify(scoresByMode));
    } catch {
      // ignore
    }
  }, [scoresByMode]);

  // Cleanup timers on unmount
  useEffect(() => clearPendingTimers, [clearPendingTimers]);

  const aiMark: Player = getOpponent(humanMark);
  const activeScores = scoresByMode[mode];
  const winInfo = roundResult?.winInfo ?? checkWinner(board);
  const isDraw = roundResult?.outcome === 'draw';
  const isRoundOver = roundResult !== null;

  const commitMove = useCallback(
    (index: number, mark: Player, fromAI: boolean) => {
      setBoard((prevBoard) => {
        if (prevBoard[index] !== null) return prevBoard;

        const nextBoard = [...prevBoard];
        nextBoard[index] = mark;

        const moveCount = nextBoard.filter((c) => c !== null).length;
        const win = checkWinner(nextBoard);
        const draw = !win && isBoardFull(nextBoard);

        setLastMoveIndex(index);
        feedback.placeMark(mark, fromAI);

        if (win) {
          setRoundResult({ outcome: 'win', winInfo: win, moveCount });
          setScoresByMode((prev) => ({
            ...prev,
            [mode]: {
              ...prev[mode],
              [win.winner]: prev[mode][win.winner] + 1,
            },
          }));
          window.setTimeout(() => feedback.celebrateWin(), 120);
          modalTimerRef.current = window.setTimeout(() => {
            setShowResultModal(true);
            modalTimerRef.current = null;
          }, 560);
        } else if (draw) {
          setRoundResult({ outcome: 'draw', winInfo: null, moveCount });
          setScoresByMode((prev) => ({
            ...prev,
            [mode]: {
              ...prev[mode],
              draws: prev[mode].draws + 1,
            },
          }));
          window.setTimeout(() => feedback.announceDraw(), 120);
          modalTimerRef.current = window.setTimeout(() => {
            setShowResultModal(true);
            modalTimerRef.current = null;
          }, 420);
        } else {
          setCurrentTurn(getOpponent(mark));
        }

        return nextBoard;
      });
    },
    [mode],
  );

  // Trigger AI turn when playing vs AI
  useEffect(() => {
    if (screen !== 'PLAYING' || mode !== 'ai' || isRoundOver) {
      setIsAIThinking(false);
      return;
    }

    if (currentTurn !== aiMark) {
      setIsAIThinking(false);
      return;
    }

    setIsAIThinking(true);
    const delayMs = board.every((c) => c === null) ? 420 : 480 + Math.floor(Math.random() * 140);

    aiTimerRef.current = window.setTimeout(() => {
      aiTimerRef.current = null;
      const moveIdx = getBestAIMove(board, aiMark, difficulty);
      setIsAIThinking(false);
      if (moveIdx !== -1) {
        commitMove(moveIdx, aiMark, true);
      }
    }, delayMs);

    return () => {
      if (aiTimerRef.current !== null) {
        window.clearTimeout(aiTimerRef.current);
        aiTimerRef.current = null;
      }
    };
  }, [screen, mode, currentTurn, aiMark, board, difficulty, isRoundOver, commitMove]);

  const startFreshRound = useCallback(
    (options?: { nextStarter?: Player; incrementRound?: boolean; silent?: boolean }) => {
      clearPendingTimers();
      const starter = options?.nextStarter ?? 'X';
      setBoard(createEmptyBoard());
      setStartingPlayer(starter);
      setCurrentTurn(starter);
      setLastMoveIndex(null);
      setIsAIThinking(false);
      setRoundResult(null);
      setShowResultModal(false);
      if (options?.incrementRound) {
        setRoundNumber((r) => r + 1);
      }
      if (!options?.silent) {
        feedback.restartRound();
      }
    },
    [clearPendingTimers],
  );

  const handleStartMatch = useCallback(() => {
    feedback.tapUI();
    setRoundNumber(1);
    startFreshRound({ nextStarter: 'X', silent: true });
    setScreen('PLAYING');
  }, [startFreshRound]);

  const handlePlayAgain = useCallback(() => {
    const nextStarter: Player =
      mode === 'local' ? getOpponent(startingPlayer) : 'X';
    startFreshRound({ nextStarter, incrementRound: true });
  }, [mode, startingPlayer, startFreshRound]);

  const handleRestartCurrentRound = useCallback(() => {
    startFreshRound({ nextStarter: startingPlayer });
  }, [startingPlayer, startFreshRound]);

  const handleResetScores = useCallback(() => {
    feedback.tapUI();
    setScoresByMode((prev) => ({
      ...prev,
      [mode]: { X: 0, O: 0, draws: 0 },
    }));
    setRoundNumber(1);
    startFreshRound({ nextStarter: 'X', silent: true });
  }, [mode, startFreshRound]);

  const handleCellSelect = useCallback(
    (index: number) => {
      if (isRoundOver || isAIThinking || showSettings) return;
      if (mode === 'ai' && currentTurn !== humanMark) return;
      if (board[index] !== null) {
        feedback.invalidTap();
        return;
      }
      commitMove(index, currentTurn, false);
    },
    [board, commitMove, currentTurn, humanMark, isAIThinking, isRoundOver, mode, showSettings],
  );

  const handleModeSwitch = useCallback(
    (nextMode: GameMode) => {
      if (nextMode === mode) return;
      feedback.tapUI();
      setMode(nextMode);
      if (screen === 'PLAYING') {
        setRoundNumber(1);
        startFreshRound({ nextStarter: 'X', silent: true });
      }
    },
    [mode, screen, startFreshRound],
  );

  const handleDifficultySwitch = useCallback(
    (nextDiff: AIDifficulty) => {
      if (nextDiff === difficulty) return;
      feedback.tapUI();
      setDifficulty(nextDiff);
      if (screen === 'PLAYING') {
        startFreshRound({ nextStarter: 'X', silent: true });
      }
    },
    [difficulty, screen, startFreshRound],
  );

  const handleHumanMarkSwitch = useCallback(
    (nextMark: Player) => {
      if (nextMark === humanMark) return;
      feedback.tapUI();
      setHumanMark(nextMark);
      if (screen === 'PLAYING') {
        startFreshRound({ nextStarter: 'X', silent: true });
      }
    },
    [humanMark, screen, startFreshRound],
  );

  const handleToggleTheme = useCallback(() => {
    feedback.tapUI();
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  }, []);

  const handleThemeChange = useCallback((nextTheme: ThemeMode) => {
    feedback.tapUI();
    setTheme(nextTheme);
  }, []);

  const handleUIStyleChange = useCallback((nextStyle: UIStyle) => {
    feedback.tapUI();
    setUIStyle(nextStyle);
  }, []);

  const handleToggleDynamicColors = useCallback(() => {
    feedback.tapUI();
    setDynamicColorsEnabled((prev) => !prev);
  }, []);

  const handleSeedColorChange = useCallback((hex: string) => {
    feedback.tapUI();
    setSeedColor(hex);
  }, []);

  const handleToggleSound = useCallback(() => {
    setSoundEnabled((prev) => {
      const next = !prev;
      feedback.configure(next, hapticsEnabled);
      if (next) feedback.tapUI();
      else feedback.vibrate('ui');
      return next;
    });
  }, [hapticsEnabled]);

  const handleToggleHaptics = useCallback(() => {
    setHapticsEnabled((prev) => {
      const next = !prev;
      feedback.configure(soundEnabled, next);
      feedback.tapUI();
      return next;
    });
  }, [soundEnabled]);

  const handleOpenSettings = useCallback(() => {
    feedback.tapUI();
    setShowSettings(true);
  }, []);

  const handleCloseSettings = useCallback(() => {
    feedback.tapUI();
    setShowSettings(false);
  }, []);

  const handleBackToMenu = useCallback(() => {
    clearPendingTimers();
    feedback.tapUI();
    setShowResultModal(false);
    setScreen('TITLE_MENU');
  }, [clearPendingTimers]);

  // Global keyboard shortcuts
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (showSettings) return;

      const target = e.target as HTMLElement | null;
      const tag = target?.tagName;
      const isInteractiveTarget = tag === 'BUTTON' || tag === 'INPUT' || tag === 'TEXTAREA';

      if (e.key === 'm' || e.key === 'M') {
        e.preventDefault();
        handleToggleSound();
        return;
      }

      if (screen === 'TITLE_MENU') {
        if ((e.key === 'Enter' || e.key === ' ') && !isInteractiveTarget) {
          e.preventDefault();
          handleStartMatch();
        }
        return;
      }

      if (e.key === 'Escape' && showResultModal) {
        e.preventDefault();
        feedback.tapUI();
        setShowResultModal(false);
        return;
      }

      if (e.key === 'r' || e.key === 'R') {
        e.preventDefault();
        if (isRoundOver) {
          handlePlayAgain();
        } else {
          handleRestartCurrentRound();
        }
        return;
      }

      if (showResultModal) {
        if (e.key === 'Enter' && !isInteractiveTarget) {
          e.preventDefault();
          handlePlayAgain();
        }
        return;
      }

      if (e.key >= '1' && e.key <= '9') {
        const idx = Number(e.key) - 1;
        e.preventDefault();
        handleCellSelect(idx);
      }
    };

    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [
    screen,
    showSettings,
    showResultModal,
    isRoundOver,
    handleStartMatch,
    handlePlayAgain,
    handleRestartCurrentRound,
    handleCellSelect,
    handleToggleSound,
  ]);

  const settingsModalNode = showSettings ? (
    <SettingsModal
      uiStyle={uiStyle}
      dynamicColorsEnabled={dynamicColorsEnabled}
      seedColor={seedColor}
      theme={theme}
      soundEnabled={soundEnabled}
      hapticsEnabled={hapticsEnabled}
      onUIStyleChange={handleUIStyleChange}
      onToggleDynamicColors={handleToggleDynamicColors}
      onSeedColorChange={handleSeedColorChange}
      onThemeChange={handleThemeChange}
      onToggleSound={handleToggleSound}
      onToggleHaptics={handleToggleHaptics}
      onClose={handleCloseSettings}
    />
  ) : null;

  if (screen === 'TITLE_MENU') {
    return (
      <>
        <TitleScreen
          mode={mode}
          difficulty={difficulty}
          humanMark={humanMark}
          theme={theme}
          uiStyle={uiStyle}
          soundEnabled={soundEnabled}
          hapticsEnabled={hapticsEnabled}
          onModeChange={handleModeSwitch}
          onDifficultyChange={handleDifficultySwitch}
          onHumanMarkChange={handleHumanMarkSwitch}
          onToggleTheme={handleToggleTheme}
          onToggleSound={handleToggleSound}
          onToggleHaptics={handleToggleHaptics}
          onOpenSettings={handleOpenSettings}
          onStartGame={handleStartMatch}
        />
        {settingsModalNode}
      </>
    );
  }

  // Labels & Turn Status Copy
  const labelX = mode === 'ai' ? (humanMark === 'X' ? 'You' : 'AI') : 'Player X';
  const labelO = mode === 'ai' ? (humanMark === 'O' ? 'You' : 'AI') : 'Player O';

  let turnMessage = '';
  let turnHighlightMark: Player | null = currentTurn;

  if (winInfo) {
    turnHighlightMark = winInfo.winner;
    if (mode === 'ai') {
      turnMessage = winInfo.winner === humanMark ? 'You win this round!' : 'AI wins this round';
    } else {
      turnMessage = `Player ${winInfo.winner} wins this round!`;
    }
  } else if (isDraw) {
    turnHighlightMark = null;
    turnMessage = 'Round ended in a draw';
  } else if (mode === 'ai') {
    turnMessage = isAIThinking || currentTurn === aiMark ? 'AI is choosing a move...' : 'Your turn';
  } else {
    turnMessage = `Player ${currentTurn}'s turn`;
  }

  const totalMatchesPlayed = activeScores.X + activeScores.O + activeScores.draws;
  const hasAnyMoves = board.some((c) => c !== null);

  return (
    <div className="min-h-dvh w-full flex flex-col justify-between px-4 py-4 sm:px-8 sm:py-6 lg:px-12">
      {/* Compact Perimeter Game HUD Bar */}
      <div className="w-full max-w-[1060px] mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={handleBackToMenu}
            aria-label="Back to title screen"
            className="m3-focus ui-btn-tonal h-11 px-4 rounded-full text-sm font-semibold flex items-center gap-2 active:scale-[0.98] cursor-pointer whitespace-nowrap shrink-0"
          >
            <ArrowLeft className="w-4 h-4 shrink-0" />
            <span>Menu</span>
          </button>

          <div className="hidden md:flex items-center gap-2 text-sm text-[var(--m3-on-surface-variant)] truncate">
            <span className="font-semibold text-[var(--m3-on-surface)]">
              {mode === 'ai' ? 'vs AI' : 'Local 2P'}
            </span>
            {mode === 'ai' && (
              <>
                <span aria-hidden="true">·</span>
                <span>{DIFFICULTY_LABELS[difficulty]}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span className="font-mono-num">Round {roundNumber}</span>
          </div>
        </div>

        {/* Utility Controls: Restart, Sound, Haptics, Theme, Settings */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            type="button"
            onClick={isRoundOver ? handlePlayAgain : handleRestartCurrentRound}
            aria-label="Restart round"
            title="Restart Round (R)"
            className="m3-focus ui-btn-tonal h-11 px-3.5 sm:px-4 rounded-full text-sm font-semibold flex items-center gap-2 active:scale-[0.98] cursor-pointer whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-4 h-4 shrink-0" />
            <span className="hidden sm:inline">{isRoundOver ? 'New Round' : 'Restart'}</span>
          </button>

          <button
            type="button"
            onClick={handleToggleSound}
            aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
            title={soundEnabled ? 'Sound On (M)' : 'Sound Off (M)'}
            className={`m3-focus ui-btn-tonal hidden sm:flex w-11 h-11 rounded-full items-center justify-center cursor-pointer shrink-0 ${
              soundEnabled ? '' : 'opacity-65'
            }`}
          >
            {soundEnabled ? (
              <Volume2 className="w-[18px] h-[18px]" />
            ) : (
              <VolumeX className="w-[18px] h-[18px]" />
            )}
          </button>

          <button
            type="button"
            onClick={handleToggleHaptics}
            aria-label={hapticsEnabled ? 'Disable haptic feedback' : 'Enable haptic feedback'}
            title={hapticsEnabled ? 'Haptics On' : 'Haptics Off'}
            className={`m3-focus ui-btn-tonal hidden sm:flex w-11 h-11 rounded-full items-center justify-center cursor-pointer shrink-0 ${
              hapticsEnabled ? '' : 'opacity-55'
            }`}
          >
            <Vibrate className="w-[18px] h-[18px]" />
          </button>

          <button
            type="button"
            onClick={handleToggleTheme}
            aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
            title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
            className="m3-focus ui-btn-tonal w-11 h-11 rounded-full flex items-center justify-center cursor-pointer shrink-0"
          >
            {theme === 'dark' ? (
              <Sun className="w-[18px] h-[18px]" />
            ) : (
              <Moon className="w-[18px] h-[18px]" />
            )}
          </button>

          <button
            type="button"
            onClick={handleOpenSettings}
            aria-label="Open settings"
            title="Settings"
            className="m3-focus ui-btn-tonal w-11 h-11 rounded-full flex items-center justify-center cursor-pointer shrink-0"
          >
            <Settings className="w-[18px] h-[18px]" />
          </button>
        </div>
      </div>

      {/* Main Play Arena */}
      <main className="w-full max-w-[1060px] mx-auto my-auto py-4 sm:py-6 grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-center">
        {/* Focal Anchor: Turn Status + 3x3 Grid */}
        <section className="lg:col-span-7 flex flex-col items-center">
          {/* Accessible Live Turn / Outcome Header */}
          <div
            aria-live="polite"
            className="w-full max-w-[436px] mb-4 flex items-center justify-between gap-3 px-1"
          >
            <div className="flex items-center gap-2.5 min-w-0">
              {turnHighlightMark ? (
                <div
                  className={`w-9 h-9 rounded-[12px] flex items-center justify-center shrink-0 ${
                    turnHighlightMark === 'X'
                      ? 'bg-[var(--m3-primary-container)]'
                      : 'bg-[var(--m3-tertiary-container)]'
                  }`}
                >
                  <MarkGlyph mark={turnHighlightMark} animated={false} size="sm" />
                </div>
              ) : (
                <div className="w-9 h-9 rounded-[12px] bg-[var(--m3-secondary-container)] flex items-center justify-center shrink-0">
                  <Trophy className="w-4 h-4 text-[var(--m3-on-secondary-container)]" />
                </div>
              )}

              <h2 className="font-display text-lg sm:text-xl font-bold tracking-tight text-[var(--m3-on-surface)] truncate">
                {turnMessage}
              </h2>
            </div>

            {isRoundOver && !showResultModal && (
              <button
                type="button"
                onClick={handlePlayAgain}
                className="m3-focus ui-btn-primary h-9 px-4 rounded-full text-xs font-semibold cursor-pointer whitespace-nowrap shrink-0"
              >
                Play Again
              </button>
            )}
          </div>

          <Board
            board={board}
            currentTurn={currentTurn}
            winInfo={winInfo}
            isDraw={isDraw}
            isLocked={isAIThinking || isRoundOver}
            lastMoveIndex={lastMoveIndex}
            onCellSelect={handleCellSelect}
            onInvalidTap={() => feedback.invalidTap()}
          />
        </section>

        {/* Side HUD Panel: Scoreboard & Live Match Controls */}
        <aside className="lg:col-span-5 w-full max-w-[436px] mx-auto lg:max-w-none flex flex-col gap-5">
          {/* Scoreboard */}
          <div className="grid grid-cols-3 gap-2.5 sm:gap-3">
            {/* Player X Score */}
            <div
              className={`rounded-[22px] p-3.5 sm:p-4 transition-[background-color,border-color,transform] duration-150 ${
                (!isRoundOver && currentTurn === 'X') || winInfo?.winner === 'X'
                  ? 'bg-[var(--m3-primary-container)] border border-[var(--m3-primary)] shadow-[var(--m3-shadow-1)] backdrop-blur-md'
                  : 'ui-panel'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <MarkGlyph mark="X" animated={false} size="sm" />
                <span className="text-[11px] font-semibold text-[var(--m3-on-surface-variant)] truncate">
                  {winInfo?.winner === 'X'
                    ? 'Winner'
                    : !isRoundOver && currentTurn === 'X'
                      ? 'Active'
                      : labelX}
                </span>
              </div>
              <div className="mt-2.5 text-3xl font-bold font-mono-num leading-none text-[var(--m3-on-surface)]">
                {activeScores.X}
              </div>
              <div className="mt-1.5 text-xs font-medium text-[var(--m3-on-surface-variant)] truncate">
                {labelX} (X)
              </div>
            </div>

            {/* Draws Score */}
            <div
              className={`rounded-[22px] p-3.5 sm:p-4 transition-[background-color,border-color] duration-150 ${
                isDraw
                  ? 'bg-[var(--m3-secondary-container)] border border-[var(--m3-secondary)] shadow-[var(--m3-shadow-1)] backdrop-blur-md'
                  : 'ui-panel'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <span className="text-xs font-bold text-[var(--m3-on-surface-variant)]">=</span>
                <span className="text-[11px] font-semibold text-[var(--m3-on-surface-variant)]">
                  {isDraw ? 'Draw' : 'Ties'}
                </span>
              </div>
              <div className="mt-2.5 text-3xl font-bold font-mono-num leading-none text-[var(--m3-on-surface)]">
                {activeScores.draws}
              </div>
              <div className="mt-1.5 text-xs font-medium text-[var(--m3-on-surface-variant)]">
                Draws
              </div>
            </div>

            {/* Player O Score */}
            <div
              className={`rounded-[22px] p-3.5 sm:p-4 transition-[background-color,border-color,transform] duration-150 ${
                (!isRoundOver && currentTurn === 'O') || winInfo?.winner === 'O'
                  ? 'bg-[var(--m3-tertiary-container)] border border-[var(--m3-tertiary)] shadow-[var(--m3-shadow-1)] backdrop-blur-md'
                  : 'ui-panel'
              }`}
            >
              <div className="flex items-center justify-between gap-1">
                <MarkGlyph mark="O" animated={false} size="sm" />
                <span className="text-[11px] font-semibold text-[var(--m3-on-surface-variant)] truncate">
                  {winInfo?.winner === 'O'
                    ? 'Winner'
                    : !isRoundOver && currentTurn === 'O'
                      ? mode === 'ai' && aiMark === 'O'
                        ? 'Thinking'
                        : 'Active'
                      : labelO}
                </span>
              </div>
              <div className="mt-2.5 text-3xl font-bold font-mono-num leading-none text-[var(--m3-on-surface)]">
                {activeScores.O}
              </div>
              <div className="mt-1.5 text-xs font-medium text-[var(--m3-on-surface-variant)] truncate">
                {labelO} (O)
              </div>
            </div>
          </div>

          {/* Match Settings Surface */}
          <div className="ui-panel rounded-[24px] p-4 sm:p-5 space-y-4">
            {/* Mode Switch */}
            <div className="grid grid-cols-2 gap-1.5 p-1 rounded-full ui-segmented">
              <button
                type="button"
                onClick={() => handleModeSwitch('ai')}
                className={`m3-focus h-10 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'ai'
                    ? 'ui-segmented-active'
                    : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                }`}
              >
                <Bot className="w-4 h-4 shrink-0" />
                <span>vs AI</span>
              </button>

              <button
                type="button"
                onClick={() => handleModeSwitch('local')}
                className={`m3-focus h-10 rounded-full text-xs sm:text-sm font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                  mode === 'local'
                    ? 'ui-segmented-active'
                    : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                }`}
              >
                <Users className="w-4 h-4 shrink-0" />
                <span>Local 2P</span>
              </button>
            </div>

            {/* AI Difficulty & Side Controls */}
            {mode === 'ai' && (
              <div className="space-y-3">
                <div className="grid grid-cols-3 gap-1 p-1 rounded-full ui-segmented">
                  {(['casual', 'smart', 'unbeatable'] as const).map((tier) => (
                    <button
                      key={tier}
                      type="button"
                      onClick={() => handleDifficultySwitch(tier)}
                      className={`m3-focus h-9 rounded-full text-xs font-semibold transition-colors cursor-pointer whitespace-nowrap ${
                        difficulty === tier
                          ? 'ui-segmented-active'
                          : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                      }`}
                    >
                      {DIFFICULTY_LABELS[tier]}
                    </button>
                  ))}
                </div>

                <div className="flex items-center justify-between gap-3 pt-1">
                  <span className="text-xs font-medium text-[var(--m3-on-surface-variant)]">
                    Play as
                  </span>
                  <div className="flex items-center gap-1 p-1 rounded-full ui-segmented">
                    <button
                      type="button"
                      onClick={() => handleHumanMarkSwitch('X')}
                      className={`m3-focus h-8 px-3.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                        humanMark === 'X'
                          ? 'ui-segmented-active'
                          : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                      }`}
                    >
                      <MarkGlyph mark="X" animated={false} size="sm" />
                      <span>First</span>
                    </button>
                    <button
                      type="button"
                      onClick={() => handleHumanMarkSwitch('O')}
                      className={`m3-focus h-8 px-3.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer whitespace-nowrap ${
                        humanMark === 'O'
                          ? 'ui-segmented-active'
                          : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                      }`}
                    >
                      <MarkGlyph mark="O" animated={false} size="sm" />
                      <span>Second</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Actions */}
            <div className="pt-1 flex items-center gap-2.5">
              <button
                type="button"
                onClick={isRoundOver ? handlePlayAgain : handleRestartCurrentRound}
                disabled={!hasAnyMoves && !isRoundOver}
                className="m3-focus ui-btn-primary flex-1 h-11 rounded-full text-sm font-semibold flex items-center justify-center gap-2 disabled:opacity-45 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap"
              >
                <RotateCcw className="w-4 h-4 shrink-0" />
                <span>{isRoundOver ? 'Play Again' : 'Restart Game'}</span>
              </button>

              <button
                type="button"
                onClick={handleResetScores}
                disabled={totalMatchesPlayed === 0}
                aria-label="Reset scoreboard"
                title="Reset Scores"
                className="m3-focus ui-btn-tonal h-11 px-4 rounded-full text-sm font-medium flex items-center justify-center gap-1.5 active:scale-[0.98] disabled:opacity-40 disabled:cursor-not-allowed cursor-pointer whitespace-nowrap shrink-0"
              >
                <Trash2 className="w-4 h-4 shrink-0" />
                <span>Reset</span>
              </button>
            </div>
          </div>
        </aside>
      </main>

      {/* Subtle flat control hint line */}
      <div className="w-full max-w-[1060px] mx-auto text-center text-xs text-[var(--m3-on-surface-variant)] pt-2">
        <span>1–9 or Click Place</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>Arrows Move Focus</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>R Restart</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>M Mute</span>
      </div>

      {/* Clear Winner / Draw Announcement Modal */}
      {showResultModal && roundResult && (
        <ResultModal
          result={roundResult}
          mode={mode}
          humanMark={humanMark}
          scores={activeScores}
          onPlayAgain={handlePlayAgain}
          onInspectBoard={() => {
            feedback.tapUI();
            setShowResultModal(false);
          }}
          onBackToMenu={handleBackToMenu}
        />
      )}

      {/* Settings Panel */}
      {settingsModalNode}
    </div>
  );
}
