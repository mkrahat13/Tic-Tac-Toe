import { useEffect } from 'react';
import {
  Check,
  Layers,
  Moon,
  Palette,
  Sparkles,
  Sun,
  Vibrate,
  Volume2,
  X,
} from 'lucide-react';
import { MATERIAL_YOU_PRESETS } from '../game/dynamicColors';
import type { ThemeMode, UIStyle } from '../game/types';

interface SettingsModalProps {
  uiStyle: UIStyle;
  dynamicColorsEnabled: boolean;
  seedColor: string;
  theme: ThemeMode;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onUIStyleChange: (style: UIStyle) => void;
  onToggleDynamicColors: () => void;
  onSeedColorChange: (hex: string) => void;
  onThemeChange: (theme: ThemeMode) => void;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onClose: () => void;
}

export function SettingsModal({
  uiStyle,
  dynamicColorsEnabled,
  seedColor,
  theme,
  soundEnabled,
  hapticsEnabled,
  onUIStyleChange,
  onToggleDynamicColors,
  onSeedColorChange,
  onThemeChange,
  onToggleSound,
  onToggleHaptics,
  onClose,
}: SettingsModalProps) {
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose();
      }
    };
    window.addEventListener('keydown', onKeyDown, true);
    return () => window.removeEventListener('keydown', onKeyDown, true);
  }, [onClose]);

  const isMaterial3 = uiStyle === 'material3';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="settings-panel-title"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-black/40 dark:bg-black/60 backdrop-blur-[3px]"
    >
      <div className="ui-modal-card animate-m3-modal w-full sm:max-w-[460px] max-h-[90dvh] overflow-y-auto rounded-t-[28px] sm:rounded-[28px] p-6 sm:p-7">
        {/* Header */}
        <div className="flex items-center justify-between gap-4 pb-5 border-b border-[var(--m3-outline-variant)]">
          <div>
            <h2
              id="settings-panel-title"
              className="font-display text-2xl font-bold tracking-tight text-[var(--m3-on-surface)]"
            >
              Settings
            </h2>
            <p className="mt-0.5 text-xs text-[var(--m3-on-surface-variant)]">
              Appearance · Design System · Feedback
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label="Close settings"
            className="m3-focus ui-btn-tonal w-10 h-10 rounded-full flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-[18px] h-[18px]" />
          </button>
        </div>

        <div className="mt-5 space-y-6">
          {/* 1. Interface Style Switcher: Material 3 vs Liquid Glass */}
          <section>
            <div className="flex items-center gap-2 mb-2.5">
              <Layers className="w-4 h-4 text-[var(--m3-primary)] shrink-0" />
              <h3 className="text-sm font-semibold text-[var(--m3-on-surface)]">
                Interface Style
              </h3>
            </div>

            <div
              role="radiogroup"
              aria-label="Interface style"
              className="grid grid-cols-2 gap-2.5"
            >
              <button
                type="button"
                role="radio"
                aria-checked={uiStyle === 'material3'}
                onClick={() => onUIStyleChange('material3')}
                className={`m3-focus rounded-[20px] p-3.5 text-left border transition-[background-color,border-color,transform] duration-150 cursor-pointer active:scale-[0.98] ${
                  uiStyle === 'material3'
                    ? 'bg-[var(--m3-primary-container)] border-[var(--m3-primary)] text-[var(--m3-on-primary-container)]'
                    : 'ui-subpanel border-[var(--m3-outline-variant)] text-[var(--m3-on-surface)] hover:border-[var(--m3-outline)]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-sm font-bold whitespace-nowrap">
                    Material 3
                  </span>
                  {uiStyle === 'material3' && <Check className="w-4 h-4 shrink-0" />}
                </div>
                <p className="mt-1 text-xs opacity-80 leading-snug">
                  Tonal surfaces, ripples, and Material You color palettes.
                </p>
              </button>

              <button
                type="button"
                role="radio"
                aria-checked={uiStyle === 'liquid-glass'}
                onClick={() => onUIStyleChange('liquid-glass')}
                className={`m3-focus rounded-[20px] p-3.5 text-left border transition-[background-color,border-color,transform] duration-150 cursor-pointer active:scale-[0.98] ${
                  uiStyle === 'liquid-glass'
                    ? 'bg-[var(--m3-primary-container)] border-[var(--m3-primary)] text-[var(--m3-on-primary-container)]'
                    : 'ui-subpanel border-[var(--m3-outline-variant)] text-[var(--m3-on-surface)] hover:border-[var(--m3-outline)]'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-display text-sm font-bold whitespace-nowrap flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 shrink-0" />
                    Liquid Glass
                  </span>
                  {uiStyle === 'liquid-glass' && <Check className="w-4 h-4 shrink-0" />}
                </div>
                <p className="mt-1 text-xs opacity-80 leading-snug">
                  Frosted translucency, specular rims, and ambient depth.
                </p>
              </button>
            </div>
          </section>

          {/* 2. Dynamic Colors (Material You) — ONLY available when Material 3 is enabled */}
          {isMaterial3 && (
            <section className="rounded-[20px] p-4 ui-subpanel border border-[var(--m3-outline-variant)] space-y-4">
              <div className="flex items-center justify-between gap-4">
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <Palette className="w-4 h-4 text-[var(--m3-primary)] shrink-0" />
                    <h3 className="text-sm font-semibold text-[var(--m3-on-surface)]">
                      Dynamic Colors
                    </h3>
                  </div>
                  <p className="mt-0.5 text-xs text-[var(--m3-on-surface-variant)]">
                    Material You tonal palette generated from your chosen seed color.
                  </p>
                </div>

                <button
                  type="button"
                  role="switch"
                  aria-checked={dynamicColorsEnabled}
                  aria-label="Enable Material You dynamic colors"
                  onClick={onToggleDynamicColors}
                  className={`m3-focus relative inline-flex h-8 w-14 shrink-0 items-center rounded-full border transition-colors duration-150 cursor-pointer ${
                    dynamicColorsEnabled
                      ? 'bg-[var(--m3-primary)] border-[var(--m3-primary)]'
                      : 'bg-[var(--m3-surface-container-highest)] border-[var(--m3-outline)]'
                  }`}
                >
                  <span
                    className={`inline-block rounded-full transition-transform duration-150 ${
                      dynamicColorsEnabled
                        ? 'h-6 w-6 translate-x-7 bg-[var(--m3-on-primary)]'
                        : 'h-4.5 w-4.5 translate-x-1.5 bg-[var(--m3-outline)]'
                    }`}
                  />
                </button>
              </div>

              {dynamicColorsEnabled && (
                <div className="pt-3 border-t border-[var(--m3-outline-variant)] space-y-2.5">
                  <div className="flex items-center justify-between text-xs text-[var(--m3-on-surface-variant)]">
                    <span className="font-medium">Seed Color</span>
                    <span className="font-mono-num uppercase">{seedColor}</span>
                  </div>

                  <div className="flex items-center flex-wrap gap-2.5">
                    {MATERIAL_YOU_PRESETS.map((preset) => {
                      const isSelected =
                        seedColor.toLowerCase() === preset.hex.toLowerCase();
                      return (
                        <button
                          key={preset.id}
                          type="button"
                          onClick={() => onSeedColorChange(preset.hex)}
                          aria-label={`Select ${preset.name} seed color`}
                          title={preset.name}
                          style={{ backgroundColor: preset.hex }}
                          className={`m3-focus w-9 h-9 rounded-full flex items-center justify-center transition-transform duration-150 cursor-pointer hover:scale-105 active:scale-95 ${
                            isSelected
                              ? 'ring-2 ring-offset-2 ring-offset-[var(--m3-surface-container)] ring-[var(--m3-on-surface)]'
                              : ''
                          }`}
                        >
                          {isSelected && <Check className="w-4 h-4 text-white" />}
                        </button>
                      );
                    })}

                    {/* Custom Seed Color Picker */}
                    <label
                      title="Pick custom seed color"
                      className="m3-focus relative h-9 px-3 rounded-full ui-btn-tonal text-xs font-semibold flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                    >
                      <span
                        aria-hidden="true"
                        style={{ backgroundColor: seedColor }}
                        className="w-3.5 h-3.5 rounded-full border border-black/20 dark:border-white/25"
                      />
                      <span>Custom</span>
                      <input
                        type="color"
                        value={seedColor}
                        onChange={(e) => onSeedColorChange(e.target.value)}
                        aria-label="Choose custom dynamic seed color"
                        className="sr-only"
                      />
                    </label>
                  </div>
                </div>
              )}
            </section>
          )}

          {/* 3. Theme Mode */}
          <section>
            <span className="block text-sm font-semibold text-[var(--m3-on-surface)] mb-2.5">
              Color Theme
            </span>
            <div
              role="radiogroup"
              aria-label="Color theme"
              className="grid grid-cols-2 gap-1.5 p-1.5 rounded-full ui-segmented"
            >
              <button
                type="button"
                role="radio"
                aria-checked={theme === 'light'}
                onClick={() => onThemeChange('light')}
                className={`m3-focus h-10 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color] duration-150 cursor-pointer whitespace-nowrap ${
                  theme === 'light'
                    ? 'ui-segmented-active'
                    : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                }`}
              >
                <Sun className="w-4 h-4 shrink-0" />
                <span>Light</span>
              </button>

              <button
                type="button"
                role="radio"
                aria-checked={theme === 'dark'}
                onClick={() => onThemeChange('dark')}
                className={`m3-focus h-10 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color] duration-150 cursor-pointer whitespace-nowrap ${
                  theme === 'dark'
                    ? 'ui-segmented-active'
                    : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                }`}
              >
                <Moon className="w-4 h-4 shrink-0" />
                <span>Dark</span>
              </button>
            </div>
          </section>

          {/* 4. Audio & Haptics */}
          <section className="space-y-2.5">
            <span className="block text-sm font-semibold text-[var(--m3-on-surface)]">
              Sensory Feedback
            </span>

            <div className="rounded-[20px] ui-subpanel border border-[var(--m3-outline-variant)] divide-y divide-[var(--m3-outline-variant)]">
              <div className="flex items-center justify-between gap-4 px-4 py-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  <Volume2 className="w-4 h-4 text-[var(--m3-on-surface-variant)] shrink-0" />
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[var(--m3-on-surface)]">
                      Sound Effects
                    </div>
                    <div className="text-xs text-[var(--m3-on-surface-variant)]">
                      Tactile chimes on moves and victories
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={soundEnabled}
                  aria-label="Toggle sound effects"
                  onClick={onToggleSound}
                  className={`m3-focus relative inline-flex h-8 w-14 shrink-0 items-center rounded-full border transition-colors duration-150 cursor-pointer ${
                    soundEnabled
                      ? 'bg-[var(--m3-primary)] border-[var(--m3-primary)]'
                      : 'bg-[var(--m3-surface-container-highest)] border-[var(--m3-outline)]'
                  }`}
                >
                  <span
                    className={`inline-block rounded-full transition-transform duration-150 ${
                      soundEnabled
                        ? 'h-6 w-6 translate-x-7 bg-[var(--m3-on-primary)]'
                        : 'h-4.5 w-4.5 translate-x-1.5 bg-[var(--m3-outline)]'
                    }`}
                  />
                </button>
              </div>

              <div className="flex items-center justify-between gap-4 px-4 py-3.5">
                <div className="flex items-center gap-3 min-w-0">
                  <Vibrate className="w-4 h-4 text-[var(--m3-on-surface-variant)] shrink-0" />
                  <div className="min-w-0">
                    <div className="text-sm font-medium text-[var(--m3-on-surface)]">
                      Haptic Feedback
                    </div>
                    <div className="text-xs text-[var(--m3-on-surface-variant)]">
                      Vibration pulses on supported devices
                    </div>
                  </div>
                </div>
                <button
                  type="button"
                  role="switch"
                  aria-checked={hapticsEnabled}
                  aria-label="Toggle haptic feedback"
                  onClick={onToggleHaptics}
                  className={`m3-focus relative inline-flex h-8 w-14 shrink-0 items-center rounded-full border transition-colors duration-150 cursor-pointer ${
                    hapticsEnabled
                      ? 'bg-[var(--m3-primary)] border-[var(--m3-primary)]'
                      : 'bg-[var(--m3-surface-container-highest)] border-[var(--m3-outline)]'
                  }`}
                >
                  <span
                    className={`inline-block rounded-full transition-transform duration-150 ${
                      hapticsEnabled
                        ? 'h-6 w-6 translate-x-7 bg-[var(--m3-on-primary)]'
                        : 'h-4.5 w-4.5 translate-x-1.5 bg-[var(--m3-outline)]'
                    }`}
                  />
                </button>
              </div>
            </div>
          </section>
        </div>

        {/* Footer Done CTA */}
        <div className="mt-6">
          <button
            type="button"
            onClick={onClose}
            className="m3-focus ui-btn-primary w-full h-11 rounded-full font-semibold text-sm flex items-center justify-center cursor-pointer whitespace-nowrap"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
}
