import type { CSSProperties } from 'react';
import type { Player } from '../game/types';

interface MarkGlyphProps {
  mark: Player;
  animated?: boolean;
  ghost?: boolean;
  size?: 'sm' | 'md' | 'lg' | 'board';
  className?: string;
}

const SIZE_CLASSES: Record<NonNullable<MarkGlyphProps['size']>, string> = {
  sm: 'w-4 h-4',
  md: 'w-6 h-6',
  lg: 'w-11 h-11',
  board: 'w-[58%] h-[58%]',
};

export function MarkGlyph({
  mark,
  animated = true,
  ghost = false,
  size = 'board',
  className = '',
}: MarkGlyphProps) {
  const strokeColor = mark === 'X' ? 'var(--m3-primary)' : 'var(--m3-tertiary)';
  const strokeWidth = size === 'sm' ? 12 : size === 'md' ? 11 : 10.5;

  if (mark === 'X') {
    const strokeStyle = { '--stroke-len': '86' } as CSSProperties;
    return (
      <svg
        viewBox="0 0 100 100"
        fill="none"
        aria-hidden="true"
        className={`${SIZE_CLASSES[size]} ${ghost ? 'opacity-25 scale-95 transition-all duration-150' : ''} ${className}`}
      >
        <line
          x1="21"
          y1="21"
          x2="79"
          y2="79"
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={animated && !ghost ? 86 : undefined}
          style={animated && !ghost ? strokeStyle : undefined}
          className={animated && !ghost ? 'animate-m3-stroke' : undefined}
        />
        <line
          x1="79"
          y1="21"
          x2="21"
          y2="79"
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          strokeLinecap="round"
          strokeDasharray={animated && !ghost ? 86 : undefined}
          style={animated && !ghost ? strokeStyle : undefined}
          className={animated && !ghost ? 'animate-m3-stroke-delay' : undefined}
        />
      </svg>
    );
  }

  const circleLen = 202;
  const circleStyle = { '--stroke-len': String(circleLen) } as CSSProperties;

  return (
    <svg
      viewBox="0 0 100 100"
      fill="none"
      aria-hidden="true"
      className={`${SIZE_CLASSES[size]} ${ghost ? 'opacity-25 scale-95 transition-all duration-150' : ''} ${className}`}
    >
      <circle
        cx="50"
        cy="50"
        r="32"
        stroke={strokeColor}
        strokeWidth={strokeWidth}
        strokeLinecap="round"
        transform="rotate(-90 50 50)"
        strokeDasharray={animated && !ghost ? circleLen : undefined}
        style={animated && !ghost ? circleStyle : undefined}
        className={animated && !ghost ? 'animate-m3-stroke' : undefined}
      />
    </svg>
  );
}

/**
 * Bespoke geometric Material 3 Title Lockup for the Title Screen
 */
export function BrandLockup() {
  return (
    <div className="flex items-center gap-4">
      <svg
        viewBox="0 0 64 64"
        fill="none"
        aria-hidden="true"
        className="w-13 h-13 shrink-0"
      >
        <rect
          x="2"
          y="2"
          width="60"
          height="60"
          rx="18"
          fill="var(--m3-surface-container-high)"
          stroke="var(--m3-outline-variant)"
          strokeWidth="1.5"
        />
        {/* Subtle grid guide */}
        <line
          x1="32"
          y1="11"
          x2="32"
          y2="53"
          stroke="var(--m3-outline-variant)"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        <line
          x1="11"
          y1="32"
          x2="53"
          y2="32"
          stroke="var(--m3-outline-variant)"
          strokeWidth="1.5"
          strokeLinecap="round"
        />
        {/* Top-left X */}
        <path
          d="M15 15L25 25M25 15L15 25"
          stroke="var(--m3-primary)"
          strokeWidth="3.6"
          strokeLinecap="round"
        />
        {/* Bottom-right X */}
        <path
          d="M39 39L49 49M49 39L39 49"
          stroke="var(--m3-primary)"
          strokeWidth="3.6"
          strokeLinecap="round"
        />
        {/* Top-right O */}
        <circle
          cx="44"
          cy="20"
          r="5.5"
          stroke="var(--m3-tertiary)"
          strokeWidth="3.4"
        />
        {/* Bottom-left O */}
        <circle
          cx="20"
          cy="44"
          r="5.5"
          stroke="var(--m3-tertiary)"
          strokeWidth="3.4"
        />
      </svg>
      <div>
        <h1 className="font-display text-4xl sm:text-[2.75rem] font-extrabold tracking-tight leading-[1.05] text-[var(--m3-on-surface)] [text-wrap:balance]">
          Tic-Tac-Toe
        </h1>
      </div>
    </div>
  );
}
