import { useEffect, useState } from 'react';
import {
  ArrowRight,
  Bot,
  Moon,
  Sun,
  Users,
  Vibrate,
  Volume2,
  VolumeX,
} from 'lucide-react';
import { checkWinner, createEmptyBoard } from '../game/engine';
import type {
  AIDifficulty,
  BoardState,
  GameMode,
  Player,
  ThemeMode,
} from '../game/types';
import { Board } from './Board';
import { BrandLockup, MarkGlyph } from './MarkGlyph';

interface TitleScreenProps {
  mode: GameMode;
  difficulty: AIDifficulty;
  humanMark: Player;
  theme: ThemeMode;
  soundEnabled: boolean;
  hapticsEnabled: boolean;
  onModeChange: (mode: GameMode) => void;
  onDifficultyChange: (difficulty: AIDifficulty) => void;
  onHumanMarkChange: (mark: Player) => void;
  onToggleTheme: () => void;
  onToggleSound: () => void;
  onToggleHaptics: () => void;
  onStartGame: () => void;
}

const DEMO_SEQUENCES: number[][] = [
  [4, 0, 2, 6, 8, 1, 7], // tactical battle -> O or X
  [0, 4, 8, 2, 6, 3, 7], // diagonal/row showcase
  [4, 2, 0, 8, 6, 3, 1], // clean diagonal win
];

export function TitleScreen({
  mode,
  difficulty,
  humanMark,
  theme,
  soundEnabled,
  hapticsEnabled,
  onModeChange,
  onDifficultyChange,
  onHumanMarkChange,
  onToggleTheme,
  onToggleSound,
  onToggleHaptics,
  onStartGame,
}: TitleScreenProps) {
  const [demoBoard, setDemoBoard] = useState<BoardState>(() => {
    const b = createEmptyBoard();
    b[0] = 'X';
    b[4] = 'O';
    b[8] = 'X';
    return b;
  });
  const [demoTurn, setDemoTurn] = useState<Player>('O');
  const [demoLastMove, setDemoLastMove] = useState<number | null>(8);

  // Subtle ambient live showcase on the Title Screen preview board
  useEffect(() => {
    const prefersReduced =
      typeof window !== 'undefined' &&
      window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReduced) return;

    let seqIdx = 0;
    let step = 0;
    let board = createEmptyBoard();
    let timerId = 0;

    const tick = () => {
      const sequence = DEMO_SEQUENCES[seqIdx];
      const existingWin = checkWinner(board);

      if (existingWin || step >= sequence.length) {
        seqIdx = (seqIdx + 1) % DEMO_SEQUENCES.length;
        step = 0;
        board = createEmptyBoard();
        setDemoBoard([...board]);
        setDemoTurn('X');
        setDemoLastMove(null);
        timerId = window.setTimeout(tick, 900);
        return;
      }

      const moveIndex = sequence[step];
      const mark: Player = step % 2 === 0 ? 'X' : 'O';
      board = [...board];
      board[moveIndex] = mark;
      step += 1;

      setDemoBoard(board);
      setDemoTurn(mark === 'X' ? 'O' : 'X');
      setDemoLastMove(moveIndex);

      const wonNow = checkWinner(board);
      timerId = window.setTimeout(tick, wonNow ? 1900 : 880);
    };

    timerId = window.setTimeout(tick, 1200);
    return () => window.clearTimeout(timerId);
  }, []);

  const demoWin = checkWinner(demoBoard);

  return (
    <div className="min-h-dvh w-full flex flex-col justify-between px-5 py-5 sm:px-8 sm:py-7 lg:px-12">
      {/* Top quiet utility controls — no website navbar */}
      <div className="w-full max-w-[1100px] mx-auto flex items-center justify-end gap-2">
        <button
          type="button"
          onClick={onToggleSound}
          aria-label={soundEnabled ? 'Mute sound effects' : 'Enable sound effects'}
          title={soundEnabled ? 'Sound On' : 'Sound Off'}
          className={`m3-focus w-11 h-11 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
            soundEnabled
              ? 'bg-[var(--m3-surface-container-high)] text-[var(--m3-on-surface)]'
              : 'bg-[var(--m3-surface-container)] text-[var(--m3-outline)]'
          } hover:bg-[var(--m3-surface-container-highest)]`}
        >
          {soundEnabled ? <Volume2 className="w-[18px] h-[18px]" /> : <VolumeX className="w-[18px] h-[18px]" />}
        </button>

        <button
          type="button"
          onClick={onToggleHaptics}
          aria-label={hapticsEnabled ? 'Disable haptic feedback' : 'Enable haptic feedback'}
          title={hapticsEnabled ? 'Haptics On' : 'Haptics Off'}
          className={`m3-focus w-11 h-11 rounded-full flex items-center justify-center transition-colors cursor-pointer ${
            hapticsEnabled
              ? 'bg-[var(--m3-surface-container-high)] text-[var(--m3-on-surface)]'
              : 'bg-[var(--m3-surface-container)] text-[var(--m3-outline)]'
          } hover:bg-[var(--m3-surface-container-highest)]`}
        >
          <Vibrate className={`w-[18px] h-[18px] ${hapticsEnabled ? '' : 'opacity-45'}`} />
        </button>

        <button
          type="button"
          onClick={onToggleTheme}
          aria-label={theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode'}
          title={theme === 'dark' ? 'Light Mode' : 'Dark Mode'}
          className="m3-focus w-11 h-11 rounded-full bg-[var(--m3-surface-container-high)] text-[var(--m3-on-surface)] flex items-center justify-center hover:bg-[var(--m3-surface-container-highest)] transition-colors cursor-pointer"
        >
          {theme === 'dark' ? <Sun className="w-[18px] h-[18px]" /> : <Moon className="w-[18px] h-[18px]" />}
        </button>
      </div>

      {/* Main Centered Split Stage */}
      <main className="w-full max-w-[1060px] mx-auto my-auto py-6 grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-14 items-center">
        {/* Left Column: Lockup, Setup & Primary Start CTA */}
        <section className="lg:col-span-6 flex flex-col items-start max-w-[460px] w-full mx-auto lg:mx-0">
          <BrandLockup />

          <p className="mt-4 text-[15px] sm:text-base leading-relaxed text-[var(--m3-on-surface-variant)] max-w-[42ch]">
            Classic three-in-a-row on a tactile Material 3 grid. Challenge an adaptive Minimax AI or pass-and-play locally.
          </p>

          {/* Match Setup Panel */}
          <div className="mt-7 w-full space-y-5">
            {/* Mode Segmented Control */}
            <div>
              <span className="block text-xs font-semibold text-[var(--m3-on-surface-variant)] mb-2">
                Game Mode
              </span>
              <div
                role="radiogroup"
                aria-label="Game mode"
                className="grid grid-cols-2 gap-1.5 p-1.5 rounded-full bg-[var(--m3-surface-container)] border border-[var(--m3-outline-variant)]"
              >
                <button
                  type="button"
                  role="radio"
                  aria-checked={mode === 'ai'}
                  onClick={() => onModeChange('ai')}
                  className={`m3-focus h-11 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color,transform] duration-150 cursor-pointer whitespace-nowrap ${
                    mode === 'ai'
                      ? 'bg-[var(--m3-primary-container)] text-[var(--m3-on-primary-container)] shadow-[var(--m3-shadow-1)]'
                      : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                  }`}
                >
                  <Bot className="w-4 h-4 shrink-0" />
                  <span>Play vs AI</span>
                </button>

                <button
                  type="button"
                  role="radio"
                  aria-checked={mode === 'local'}
                  onClick={() => onModeChange('local')}
                  className={`m3-focus h-11 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color,transform] duration-150 cursor-pointer whitespace-nowrap ${
                    mode === 'local'
                      ? 'bg-[var(--m3-primary-container)] text-[var(--m3-on-primary-container)] shadow-[var(--m3-shadow-1)]'
                      : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                  }`}
                >
                  <Users className="w-4 h-4 shrink-0" />
                  <span>Local 2P</span>
                </button>
              </div>
            </div>

            {/* AI Options: Difficulty + Mark Choice */}
            {mode === 'ai' && (
              <div className="space-y-4">
                <div>
                  <span className="block text-xs font-semibold text-[var(--m3-on-surface-variant)] mb-2">
                    AI Difficulty
                  </span>
                  <div
                    role="radiogroup"
                    aria-label="AI difficulty"
                    className="grid grid-cols-3 gap-1.5 p-1.5 rounded-full bg-[var(--m3-surface-container)] border border-[var(--m3-outline-variant)]"
                  >
                    {(
                      [
                        { id: 'casual', label: 'Casual' },
                        { id: 'smart', label: 'Smart' },
                        { id: 'unbeatable', label: 'Unbeatable' },
                      ] as const
                    ).map((tier) => (
                      <button
                        key={tier.id}
                        type="button"
                        role="radio"
                        aria-checked={difficulty === tier.id}
                        onClick={() => onDifficultyChange(tier.id)}
                        className={`m3-focus h-10 rounded-full text-xs sm:text-sm font-semibold transition-[background-color,color] duration-150 cursor-pointer whitespace-nowrap ${
                          difficulty === tier.id
                            ? 'bg-[var(--m3-surface-container-lowest)] text-[var(--m3-on-surface)] shadow-[var(--m3-shadow-1)]'
                            : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                        }`}
                      >
                        {tier.label}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <span className="block text-xs font-semibold text-[var(--m3-on-surface-variant)] mb-2">
                    Your Mark
                  </span>
                  <div
                    role="radiogroup"
                    aria-label="Choose your mark"
                    className="grid grid-cols-2 gap-1.5 p-1.5 rounded-full bg-[var(--m3-surface-container)] border border-[var(--m3-outline-variant)]"
                  >
                    <button
                      type="button"
                      role="radio"
                      aria-checked={humanMark === 'X'}
                      onClick={() => onHumanMarkChange('X')}
                      className={`m3-focus h-10 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color] duration-150 cursor-pointer whitespace-nowrap ${
                        humanMark === 'X'
                          ? 'bg-[var(--m3-surface-container-lowest)] text-[var(--m3-on-surface)] shadow-[var(--m3-shadow-1)]'
                          : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                      }`}
                    >
                      <MarkGlyph mark="X" animated={false} size="sm" />
                      <span>Play as X (First)</span>
                    </button>

                    <button
                      type="button"
                      role="radio"
                      aria-checked={humanMark === 'O'}
                      onClick={() => onHumanMarkChange('O')}
                      className={`m3-focus h-10 rounded-full text-sm font-semibold flex items-center justify-center gap-2 transition-[background-color,color] duration-150 cursor-pointer whitespace-nowrap ${
                        humanMark === 'O'
                          ? 'bg-[var(--m3-surface-container-lowest)] text-[var(--m3-on-surface)] shadow-[var(--m3-shadow-1)]'
                          : 'text-[var(--m3-on-surface-variant)] hover:text-[var(--m3-on-surface)]'
                      }`}
                    >
                      <MarkGlyph mark="O" animated={false} size="sm" />
                      <span>Play as O (Second)</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Primary Start CTA */}
            <button
              type="button"
              onClick={onStartGame}
              className="m3-focus mt-2 w-full h-13 rounded-full bg-[var(--m3-primary)] text-[var(--m3-on-primary)] font-display font-bold text-base flex items-center justify-center gap-2.5 shadow-[var(--m3-shadow-2)] hover:brightness-110 active:scale-[0.98] transition-[transform,filter] duration-150 cursor-pointer whitespace-nowrap"
            >
              <span>Start Match</span>
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* Right Column: Live Ambient Preview Board */}
        <section className="lg:col-span-6 flex flex-col items-center justify-center">
          <div
            onClick={onStartGame}
            role="button"
            tabIndex={0}
            aria-label="Start match from preview board"
            onKeyDown={(e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onStartGame();
              }
            }}
            className="m3-focus group relative flex flex-col items-center cursor-pointer rounded-[32px] transition-transform duration-200 hover:scale-[1.015] active:scale-[0.99]"
          >
            <Board
              board={demoBoard}
              currentTurn={demoTurn}
              winInfo={demoWin}
              isDraw={false}
              isLocked
              lastMoveIndex={demoLastMove}
              onCellSelect={() => {}}
              compact
              interactive={false}
            />
          </div>
        </section>
      </main>

      {/* Single flat control-hint line */}
      <div className="w-full max-w-[1100px] mx-auto text-center text-xs text-[var(--m3-on-surface-variant)]">
        <span>Enter Start</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>Click or 1–9 Place</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>Arrows Navigate</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>R Restart</span>
        <span className="mx-2 opacity-50" aria-hidden="true">·</span>
        <span>M Mute</span>
      </div>
    </div>
  );
}
