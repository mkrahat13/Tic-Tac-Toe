import { Eye, RotateCcw, SlidersHorizontal, Trophy } from 'lucide-react';
import type { GameMode, Player, RoundResult, ScoreBoard } from '../game/types';
import { MarkGlyph } from './MarkGlyph';

interface ResultModalProps {
  result: RoundResult;
  mode: GameMode;
  humanMark: Player;
  scores: ScoreBoard;
  onPlayAgain: () => void;
  onInspectBoard: () => void;
  onBackToMenu: () => void;
}

export function ResultModal({
  result,
  mode,
  humanMark,
  scores,
  onPlayAgain,
  onInspectBoard,
  onBackToMenu,
}: ResultModalProps) {
  const winner = result.winInfo?.winner ?? null;

  let headline = 'Round Drawn';
  let subtitle = `Balanced stalemate · ${result.moveCount} moves`;
  let emblemBg = 'bg-[var(--m3-secondary-container)]';

  if (winner) {
    if (mode === 'ai') {
      const humanWon = winner === humanMark;
      headline = humanWon ? 'You Win!' : 'AI Wins';
    } else {
      headline = `Player ${winner} Wins!`;
    }
    subtitle = `${result.winInfo?.label ?? 'Three in a row'} · ${result.moveCount} moves`;
    emblemBg =
      winner === 'X'
        ? 'bg-[var(--m3-primary-container)]'
        : 'bg-[var(--m3-tertiary-container)]';
  }

  const labelX = mode === 'ai' ? (humanMark === 'X' ? 'You (X)' : 'AI (X)') : 'Player X';
  const labelO = mode === 'ai' ? (humanMark === 'O' ? 'You (O)' : 'AI (O)') : 'Player O';

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="result-modal-title"
      className="fixed inset-0 z-40 flex items-center justify-center p-4 bg-black/45 dark:bg-black/65"
    >
      <div className="animate-m3-modal w-full max-w-[400px] rounded-[28px] bg-[var(--m3-surface-container-lowest)] border border-[var(--m3-outline-variant)] shadow-[var(--m3-shadow-3)] p-6 sm:p-7">
        {/* Emblem + Announcement */}
        <div className="flex flex-col items-center text-center">
          <div
            className={`w-16 h-16 rounded-[20px] ${emblemBg} flex items-center justify-center mb-4`}
          >
            {winner ? (
              <MarkGlyph mark={winner} animated size="lg" />
            ) : (
              <Trophy className="w-7 h-7 text-[var(--m3-on-secondary-container)]" />
            )}
          </div>

          <h2
            id="result-modal-title"
            className="font-display text-3xl font-extrabold tracking-tight text-[var(--m3-on-surface)] [text-wrap:balance]"
          >
            {headline}
          </h2>

          <p className="mt-1.5 text-sm text-[var(--m3-on-surface-variant)]">
            {subtitle}
          </p>
        </div>

        {/* Score Recap Strip */}
        <div className="mt-6 grid grid-cols-3 gap-2 rounded-[20px] bg-[var(--m3-surface-container)] p-3 text-center">
          <div>
            <div className="text-xs font-medium text-[var(--m3-on-surface-variant)] truncate">
              {labelX}
            </div>
            <div className="mt-0.5 text-2xl font-bold font-mono-num text-[var(--m3-primary)]">
              {scores.X}
            </div>
          </div>
          <div className="border-x border-[var(--m3-outline-variant)]">
            <div className="text-xs font-medium text-[var(--m3-on-surface-variant)]">
              Draws
            </div>
            <div className="mt-0.5 text-2xl font-bold font-mono-num text-[var(--m3-on-surface)]">
              {scores.draws}
            </div>
          </div>
          <div>
            <div className="text-xs font-medium text-[var(--m3-on-surface-variant)] truncate">
              {labelO}
            </div>
            <div className="mt-0.5 text-2xl font-bold font-mono-num text-[var(--m3-tertiary)]">
              {scores.O}
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="mt-6 flex flex-col gap-2.5">
          <button
            type="button"
            autoFocus
            onClick={onPlayAgain}
            className="m3-focus w-full h-12 rounded-full bg-[var(--m3-primary)] text-[var(--m3-on-primary)] font-semibold text-[15px] flex items-center justify-center gap-2 hover:brightness-110 active:scale-[0.98] transition-[transform,filter] duration-150 cursor-pointer whitespace-nowrap"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Play Again</span>
          </button>

          <div className="grid grid-cols-2 gap-2.5">
            <button
              type="button"
              onClick={onInspectBoard}
              className="m3-focus h-11 rounded-full bg-[var(--m3-surface-container-high)] text-[var(--m3-on-surface)] text-sm font-medium flex items-center justify-center gap-1.5 hover:bg-[var(--m3-surface-container-highest)] active:scale-[0.98] transition-[transform,background-color] duration-150 cursor-pointer whitespace-nowrap"
            >
              <Eye className="w-4 h-4" />
              <span>View Board</span>
            </button>

            <button
              type="button"
              onClick={onBackToMenu}
              className="m3-focus h-11 rounded-full bg-[var(--m3-surface-container-high)] text-[var(--m3-on-surface)] text-sm font-medium flex items-center justify-center gap-1.5 hover:bg-[var(--m3-surface-container-highest)] active:scale-[0.98] transition-[transform,background-color] duration-150 cursor-pointer whitespace-nowrap"
            >
              <SlidersHorizontal className="w-4 h-4" />
              <span>Change Mode</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
