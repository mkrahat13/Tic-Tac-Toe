import { useRef, useState } from 'react';
import type { KeyboardEvent, MouseEvent } from 'react';
import type { BoardState, Player, WinInfo } from '../game/types';
import { MarkGlyph } from './MarkGlyph';

interface RippleItem {
  id: number;
  cellIndex: number;
  x: number;
  y: number;
  mark: Player;
}

interface BoardProps {
  board: BoardState;
  currentTurn: Player;
  winInfo: WinInfo | null;
  isDraw: boolean;
  isLocked: boolean;
  lastMoveIndex: number | null;
  onCellSelect: (index: number) => void;
  onInvalidTap?: () => void;
  compact?: boolean;
  interactive?: boolean;
}

const CELL_LABELS = [
  'Row 1, Column 1',
  'Row 1, Column 2',
  'Row 1, Column 3',
  'Row 2, Column 1',
  'Row 2, Column 2',
  'Row 2, Column 3',
  'Row 3, Column 1',
  'Row 3, Column 2',
  'Row 3, Column 3',
];

export function Board({
  board,
  currentTurn,
  winInfo,
  isDraw,
  isLocked,
  lastMoveIndex,
  onCellSelect,
  onInvalidTap,
  compact = false,
  interactive = true,
}: BoardProps) {
  const [ripples, setRipples] = useState<RippleItem[]>([]);
  const [hoveredCell, setHoveredCell] = useState<number | null>(null);
  const cellRefs = useRef<Array<HTMLButtonElement | null>>([]);
  const rippleCounter = useRef(0);

  const triggerRipple = (cellIndex: number, e: MouseEvent<HTMLButtonElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX ? e.clientX - rect.left : rect.width / 2;
    const y = e.clientY ? e.clientY - rect.top : rect.height / 2;
    const id = ++rippleCounter.current;
    setRipples((prev) => [...prev, { id, cellIndex, x, y, mark: currentTurn }]);
    window.setTimeout(() => {
      setRipples((prev) => prev.filter((item) => item.id !== id));
    }, 460);
  };

  const handleClick = (index: number, e: MouseEvent<HTMLButtonElement>) => {
    if (!interactive) return;
    if (isLocked || winInfo || isDraw) return;
    if (board[index] !== null) {
      onInvalidTap?.();
      return;
    }
    triggerRipple(index, e);
    onCellSelect(index);
  };

  const handleKeyDown = (index: number, e: KeyboardEvent<HTMLButtonElement>) => {
    if (!interactive) return;
    const row = Math.floor(index / 3);
    const col = index % 3;
    let nextIndex: number | null = null;

    switch (e.key) {
      case 'ArrowRight':
        nextIndex = row * 3 + ((col + 1) % 3);
        break;
      case 'ArrowLeft':
        nextIndex = row * 3 + ((col + 2) % 3);
        break;
      case 'ArrowDown':
        nextIndex = ((row + 1) % 3) * 3 + col;
        break;
      case 'ArrowUp':
        nextIndex = ((row + 2) % 3) * 3 + col;
        break;
      default:
        return;
    }

    if (nextIndex !== null) {
      e.preventDefault();
      cellRefs.current[nextIndex]?.focus();
    }
  };

  const winningSet = winInfo ? new Set(winInfo.line) : null;
  const winStrokeColor =
    winInfo?.winner === 'X' ? 'var(--m3-primary)' : 'var(--m3-tertiary)';

  return (
    <div
      className={`relative w-full aspect-square select-none ${
        compact ? 'max-w-[330px] p-3 rounded-[28px]' : 'max-w-[436px] p-3.5 sm:p-4 rounded-[32px]'
      } bg-[var(--m3-surface-container)] border border-[var(--m3-outline-variant)] shadow-[var(--m3-shadow-2)]`}
    >
      <div
        role="grid"
        aria-label="Tic-Tac-Toe 3 by 3 board"
        className={`relative grid grid-cols-3 grid-rows-3 w-full h-full ${
          compact ? 'gap-2.5' : 'gap-2.5 sm:gap-3.5'
        }`}
      >
        {board.map((cell, index) => {
          const isWinCell = winningSet?.has(index) ?? false;
          const isDimmed = Boolean((winInfo && !isWinCell) || isDraw);
          const isPlayable = interactive && !isLocked && !winInfo && !isDraw && cell === null;
          const isLastMove = lastMoveIndex === index && cell !== null && !winInfo;
          const showGhost = isPlayable && hoveredCell === index;
          const cellRipples = ripples.filter((r) => r.cellIndex === index);

          let surfaceClasses =
            'bg-[var(--m3-surface-container-lowest)] hover:bg-[var(--m3-surface-container-low)]';

          if (isWinCell && winInfo?.winner === 'X') {
            surfaceClasses = 'bg-[var(--m3-primary-container)] animate-m3-win-cell';
          } else if (isWinCell && winInfo?.winner === 'O') {
            surfaceClasses = 'bg-[var(--m3-tertiary-container)] animate-m3-win-cell';
          } else if (!isPlayable) {
            surfaceClasses = 'bg-[var(--m3-surface-container-lowest)]';
          }

          return (
            <button
              key={index}
              ref={(el) => {
                cellRefs.current[index] = el;
              }}
              type="button"
              role="gridcell"
              tabIndex={interactive ? 0 : -1}
              aria-label={`${CELL_LABELS[index]}, ${cell ? `occupied by ${cell}` : 'empty'}`}
              aria-disabled={!isPlayable}
              onClick={(e) => handleClick(index, e)}
              onKeyDown={(e) => handleKeyDown(index, e)}
              onMouseEnter={() => isPlayable && setHoveredCell(index)}
              onMouseLeave={() => setHoveredCell((prev) => (prev === index ? null : prev))}
              className={`m3-focus relative flex items-center justify-center overflow-hidden ${
                compact ? 'rounded-[18px]' : 'rounded-[20px]'
              } ${surfaceClasses} transition-[transform,opacity,background-color] duration-150 ease-out ${
                isPlayable
                  ? 'cursor-pointer active:scale-[0.96]'
                  : interactive
                    ? 'cursor-default'
                    : 'cursor-default pointer-events-none'
              } ${isDimmed ? 'opacity-55' : 'opacity-100'} ${
                isLastMove
                  ? 'ring-2 ring-inset ring-[var(--m3-outline-variant)]'
                  : 'shadow-[var(--m3-shadow-1)]'
              }`}
            >
              {/* Material 3 tactile ripple wave */}
              {cellRipples.map((ripple) => (
                <span
                  key={ripple.id}
                  aria-hidden="true"
                  style={{
                    left: ripple.x,
                    top: ripple.y,
                    backgroundColor:
                      ripple.mark === 'X' ? 'var(--m3-primary)' : 'var(--m3-tertiary)',
                  }}
                  className="pointer-events-none absolute w-24 h-24 rounded-full animate-m3-ripple"
                />
              ))}

              {/* Subtle keyboard key index hint on desktop hover for empty cells */}
              {!compact && isPlayable && (
                <span
                  aria-hidden="true"
                  className="pointer-events-none absolute top-2 left-2.5 text-[11px] font-mono-num text-[var(--m3-outline)] opacity-0 sm:opacity-35 transition-opacity"
                >
                  {index + 1}
                </span>
              )}

              {/* Placed mark or hover ghost */}
              {cell ? (
                <MarkGlyph mark={cell} animated size="board" />
              ) : showGhost ? (
                <MarkGlyph mark={currentTurn} animated={false} ghost size="board" />
              ) : null}
            </button>
          );
        })}

        {/* Animated Winning Line Overlay */}
        {winInfo && (
          <svg
            viewBox="0 0 300 300"
            fill="none"
            aria-hidden="true"
            className="pointer-events-none absolute inset-0 w-full h-full z-10"
          >
            {/* Soft underlay glow for legibility across both themes */}
            <line
              x1={winInfo.geometry.x1}
              y1={winInfo.geometry.y1}
              x2={winInfo.geometry.x2}
              y2={winInfo.geometry.y2}
              stroke="var(--m3-surface-container-lowest)"
              strokeOpacity="0.55"
              strokeWidth="15"
              strokeLinecap="round"
              className="animate-m3-win-line"
            />
            <line
              x1={winInfo.geometry.x1}
              y1={winInfo.geometry.y1}
              x2={winInfo.geometry.x2}
              y2={winInfo.geometry.y2}
              stroke={winStrokeColor}
              strokeWidth="9"
              strokeLinecap="round"
              className="animate-m3-win-line"
            />
          </svg>
        )}
      </div>
    </div>
  );
}
