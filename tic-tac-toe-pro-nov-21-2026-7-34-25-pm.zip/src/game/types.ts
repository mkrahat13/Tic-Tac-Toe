export type Player = 'X' | 'O';
export type CellValue = Player | null;
export type BoardState = CellValue[];

export type GameMode = 'ai' | 'local';
export type AIDifficulty = 'casual' | 'smart' | 'unbeatable';
export type GameScreen = 'TITLE_MENU' | 'PLAYING';
export type ThemeMode = 'light' | 'dark';

export interface WinLineGeometry {
  x1: number;
  y1: number;
  x2: number;
  y2: number;
}

export interface WinInfo {
  winner: Player;
  line: [number, number, number];
  geometry: WinLineGeometry;
  label: string;
}

export interface ScoreBoard {
  X: number;
  O: number;
  draws: number;
}

export interface RoundResult {
  outcome: 'win' | 'draw';
  winInfo: WinInfo | null;
  moveCount: number;
}
